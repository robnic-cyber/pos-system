<?php
namespace Config;
use CodeIgniter\Config\Filters as BaseFilters;
class Filters extends BaseFilters { public array $aliases = ['auth' => \App\Filters\AuthFilter::class]; }
