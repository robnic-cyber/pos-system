# Complete Point of Sale System

## IT0049 Midterm Project

This CodeIgniter 4 application implements the required POS workflow: authentication, protected management pages, product/customer/staff CRUD, safe image uploads, hashed staff passwords, stock-aware sale recording, and sales history.

## Group members

- Azea Kirsten E. Natividad
- Alyanah Louise P. Nofuente
- Jusmer James Edward C. Hica

## Setup

1. Install PHP 8.1+, Composer, and MySQL.
2. Copy `.env.example` to `.env`, then set the database values.
3. Run `composer install`.
4. Import `database.sql` into MySQL.
5. Run `php spark serve` and open `http://localhost:8080`.
6. Default account: `admin` / `password`.

Change the default password before deployment. Uploaded images are limited to image MIME types and stored under `public/uploads`.

## Submission links

- GitHub repository: **To be added after the group creates/pushes the repository**
- Hosted application: **To be added after deployment**

## Requirements covered

The schema preserves the required product, customer, users, and sales relationships. Sales run in a database transaction, reject quantities greater than available stock, calculate total price from the current product price, and decrement inventory only after a valid sale.
